import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Pipeline model
export interface Pipeline {
  id: string;
  name: string;
  type: "web" | "api" | "service" | "auth";
  buildNumber: number;
  triggeredBy: string;
  triggeredAt: Date;
  status: "running" | "success" | "failed" | "fixing";
  duration: number;
  stages: {
    name: string;
    status: "success" | "failed" | "running" | "pending";
  }[];
}

// Build history model
export interface BuildHistoryItem {
  id?: number;
  name: string;
  buildNumber: number;
  status: "completed" | "failed" | "warning";
  timestamp: Date;
  day: "Today" | "Yesterday" | string;
}

// Dashboard metrics model
export interface DashboardMetrics {
  activePipelines: number;
  totalPipelines: number;
  successRate: number;
  avgBuildTime: string;
  failedDeployments: number;
}

// Deployment metrics model
export interface DeploymentMetrics {
  successRate: number;
  successRateChange: number;
  totalDeployments: number;
  totalDeploymentsChange: number;
  data: {
    day: string;
    success: number;
    failed: number;
    warning: number;
  }[];
}

// Define metrics table to store dashboard metrics
export const metrics = pgTable("metrics", {
  id: serial("id").primaryKey(),
  activePipelines: integer("active_pipelines").notNull().default(0),
  totalPipelines: integer("total_pipelines").notNull().default(0),
  successRate: integer("success_rate").notNull().default(0),
  avgBuildTime: text("avg_build_time").notNull().default("0:00"),
  failedDeployments: integer("failed_deployments").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Define deployment metrics table
export const deploymentMetrics = pgTable("deployment_metrics", {
  id: serial("id").primaryKey(),
  successRate: integer("success_rate").notNull().default(0),
  successRateChange: integer("success_rate_change").notNull().default(0),
  totalDeployments: integer("total_deployments").notNull().default(0),
  totalDeploymentsChange: integer("total_deployments_change").notNull().default(0),
  data: json("data").notNull().$type<{ day: string, success: number, failed: number, warning: number }[]>(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Define pipeline stages table
export const pipelineStages = pgTable("pipeline_stages", {
  id: serial("id").primaryKey(),
  pipelineId: text("pipeline_id").notNull().references(() => pipelines.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  status: text("status").notNull(),
  order: integer("order").notNull(),
});

// Database schema for pipelines
export const pipelines = pgTable("pipelines", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  buildNumber: integer("build_number").notNull(),
  triggeredBy: text("triggered_by").notNull(),
  triggeredAt: timestamp("triggered_at").notNull(),
  status: text("status").notNull(),
  duration: integer("duration").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Define relation between pipelines and stages
export const pipelinesRelations = relations(pipelines, ({ many }) => ({
  stages: many(pipelineStages),
}));

export const pipelineStagesRelations = relations(pipelineStages, ({ one }) => ({
  pipeline: one(pipelines, {
    fields: [pipelineStages.pipelineId],
    references: [pipelines.id],
  }),
}));

export const buildHistory = pgTable("build_history", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  buildNumber: integer("build_number").notNull(),
  status: text("status").notNull(),
  timestamp: timestamp("timestamp").notNull(),
  day: text("day").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertPipelineSchema = createInsertSchema(pipelines);
export const insertBuildHistorySchema = createInsertSchema(buildHistory);
export const insertPipelineStageSchema = createInsertSchema(pipelineStages);
export const insertMetricsSchema = createInsertSchema(metrics);
export const insertDeploymentMetricsSchema = createInsertSchema(deploymentMetrics);

export type InsertPipeline = z.infer<typeof insertPipelineSchema>;
export type InsertBuildHistory = z.infer<typeof insertBuildHistorySchema>;
export type InsertPipelineStage = z.infer<typeof insertPipelineStageSchema>;
export type InsertMetrics = z.infer<typeof insertMetricsSchema>;
export type InsertDeploymentMetrics = z.infer<typeof insertDeploymentMetricsSchema>;
