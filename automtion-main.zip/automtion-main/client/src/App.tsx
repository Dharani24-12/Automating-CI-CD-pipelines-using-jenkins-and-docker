import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import { useEffect, useState } from "react";
import { setupWebSocket } from "./lib/websocket";
import Dashboard from "@/pages/dashboard";
import NotFound from "@/pages/not-found";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { useNotifications } from "@/hooks/use-notification";
import ErrorBoundary from "@/components/error-boundary";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const { addNotification } = useNotifications();
  const [wsConnected, setWsConnected] = useState(false);

  useEffect(() => {
    const cleanup = setupWebSocket({
      onOpen: () => {
        console.log("WebSocket connected in App component");
        setWsConnected(true);
        addNotification({
          id: `ws-connected-${Date.now()}`,
          title: 'WebSocket Connected',
          message: 'Real-time updates are now enabled',
          type: 'success',
          timestamp: new Date(),
          duration: 3000
        });
      },
      onClose: () => {
        console.log("WebSocket disconnected in App component");
        setWsConnected(false);
      },
      onError: (error) => {
        console.error("WebSocket error in App component:", error);
        addNotification({
          id: `ws-error-${Date.now()}`,
          title: 'Connection Error',
          message: 'Unable to establish real-time connection',
          type: 'error',
          timestamp: new Date(),
          duration: 5000
        });
      },
      onMessage: (data) => {
        console.log("Received WebSocket message:", data);
        if (data.type === 'notification') {
          addNotification({
            id: data.id,
            title: data.title,
            message: data.message,
            type: data.notificationType,
            timestamp: new Date()
          });
        }
      }
    });
    
    return () => {
      cleanup();
    };
  }, [addNotification]);

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="light">
        <TooltipProvider>
          <div className="min-h-screen flex flex-col">
            <Header wsConnected={wsConnected} />
            <div className="flex-1 flex flex-col md:flex-row">
              <ErrorBoundary>
                <Router />
              </ErrorBoundary>
            </div>
            <Footer />
            <Toaster />
          </div>
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
