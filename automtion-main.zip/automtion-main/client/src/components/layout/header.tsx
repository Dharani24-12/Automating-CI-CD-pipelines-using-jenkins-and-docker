import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useNotifications } from "@/hooks/use-notification";
import { Bell, Search, Wifi, WifiOff } from "lucide-react";
import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";

interface HeaderProps {
  wsConnected?: boolean;
}

export default function Header({ wsConnected = false }: HeaderProps) {
  const { notifications } = useNotifications();
  const [hasNew, setHasNew] = useState(false);

  useEffect(() => {
    if (notifications.length > 0) {
      setHasNew(true);
    }
  }, [notifications]);

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M2 5a2 2 0 012-2h12a2 2 0 012 2v10a2 2 0 01-2 2H4a2 2 0 01-2-2V5zm2-1h12a1 1 0 011 1v10a1 1 0 01-1 1H4a1 1 0 01-1-1V5a1 1 0 011-1z" clipRule="evenodd" />
              <path d="M6 7.75A.75.75 0 016.75 7h6.5a.75.75 0 010 1.5h-6.5A.75.75 0 016 7.75zM6 10.75a.75.75 0 01.75-.75h6.5a.75.75 0 010 1.5h-6.5a.75.75 0 01-.75-.75zM7.75 13a.75.75 0 000 1.5h4.5a.75.75 0 000-1.5h-4.5z" />
            </svg>
            <h1 className="text-xl font-semibold ml-2">CI/CD Dashboard</h1>
          </div>
          <div className="border-l border-gray-300 h-6 hidden md:block"></div>
          <div className="hidden md:flex items-center text-sm">
            <span className="text-medium">Organization:</span>
            <span className="font-medium ml-1">TechCorp</span>
          </div>
          <div className="hidden md:block">
            <Badge variant="outline" className={wsConnected 
              ? "bg-success/10 text-success border-success/20 flex items-center" 
              : "bg-error/10 text-error border-error/20 flex items-center"}>
              {wsConnected 
                ? <><Wifi className="h-3 w-3 mr-1" /> Connected</> 
                : <><WifiOff className="h-3 w-3 mr-1" /> Offline</>}
            </Badge>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="hidden sm:block relative">
            <Input 
              type="text"
              placeholder="Search pipelines..."
              className="bg-gray-100 rounded-md py-1.5 px-3 text-sm w-56 focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
            <Search className="h-4 w-4 text-medium absolute top-2 right-3" />
          </div>
          <Button 
            variant="outline" 
            size="icon" 
            className="p-1.5 rounded-full bg-gray-100 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-primary/50 relative"
          >
            <Bell className="h-5 w-5 text-medium" />
            {hasNew && <span className="notification-dot bg-error animate-pulse"></span>}
          </Button>
          <div className="hidden md:flex items-center space-x-2">
            <Avatar className="h-8 w-8 bg-primary text-white">
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
            <span className="text-sm font-medium">John Doe</span>
          </div>
        </div>
      </div>
    </header>
  );
}
