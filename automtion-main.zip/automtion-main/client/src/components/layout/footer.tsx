export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200 py-4">
      <div className="container mx-auto px-4 flex flex-col md:flex-row md:items-center md:justify-between text-sm text-medium">
        <div>
          <p>© {new Date().getFullYear()} CI/CD Dashboard. All rights reserved.</p>
        </div>
        <div className="mt-2 md:mt-0 flex items-center space-x-4">
          <a href="#" className="hover:text-primary">Documentation</a>
          <a href="#" className="hover:text-primary">Support</a>
          <a href="#" className="hover:text-primary">Privacy Policy</a>
        </div>
      </div>
    </footer>
  );
}
