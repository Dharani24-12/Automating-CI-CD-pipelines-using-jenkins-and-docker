import { cn } from "@/lib/utils";
import { BarChart3, Cog, FolderTree, Home, List } from "lucide-react";
import { Link, useLocation } from "wouter";

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  active?: boolean;
}

function NavItem({ href, icon, children, active }: NavItemProps) {
  return (
    <li>
      <Link href={href}>
        <a className={cn(
          "flex items-center space-x-3 px-3 py-2 rounded-md",
          active ? "bg-primary text-white" : "text-dark hover:bg-gray-100"
        )}>
          {icon}
          <span className={active ? "font-medium" : ""}>{children}</span>
        </a>
      </Link>
    </li>
  );
}

interface RecentPipelineProps {
  name: string;
  status: "success" | "error" | "warning" | "info";
}

function RecentPipeline({ name, status }: RecentPipelineProps) {
  const statusColors = {
    success: "bg-success",
    error: "bg-error",
    warning: "bg-warning",
    info: "bg-info"
  };

  return (
    <li>
      <a href="#" className="flex items-center text-sm px-3 py-1.5 rounded-md text-dark hover:bg-gray-100">
        <span className={cn("w-2 h-2 rounded-full mr-2", statusColors[status])}></span>
        <span className="truncate">{name}</span>
      </a>
    </li>
  );
}

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <nav className="bg-white shadow-sm md:w-56 lg:w-64 md:h-screen md:sticky top-0">
      <div className="px-3 py-4">
        <ul className="space-y-1">
          <NavItem href="/" icon={<Home className="h-5 w-5" />} active={location === "/"}>
            Dashboard
          </NavItem>
          <NavItem href="/pipelines" icon={<FolderTree className="h-5 w-5" />} active={location === "/pipelines"}>
            Pipelines
          </NavItem>
          <NavItem href="/history" icon={<List className="h-5 w-5" />} active={location === "/history"}>
            Build History
          </NavItem>
          <NavItem href="/analytics" icon={<BarChart3 className="h-5 w-5" />} active={location === "/analytics"}>
            Analytics
          </NavItem>
          <NavItem href="/settings" icon={<Cog className="h-5 w-5" />} active={location === "/settings"}>
            Settings
          </NavItem>
        </ul>
        
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="px-3">
            <h3 className="text-xs font-medium uppercase text-medium tracking-wider">Recent Pipelines</h3>
            <ul className="mt-2 space-y-1">
              <RecentPipeline name="web-frontend" status="success" />
              <RecentPipeline name="api-gateway" status="error" />
              <RecentPipeline name="user-service" status="warning" />
              <RecentPipeline name="auth-service" status="info" />
            </ul>
          </div>
        </div>
      </div>
    </nav>
  );
}
