import { PipelineStage, StageStatus } from "@/components/ui/pipeline-stage";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatTimeAgo } from "@/lib/utils";
import { Clock, Laptop, Monitor, MoreVertical, Server } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export interface PipelineStageData {
  name: string;
  status: StageStatus;
}

export interface PipelineItemProps {
  id: string;
  name: string;
  type: "web" | "api" | "service" | "auth";
  buildNumber: number;
  triggeredBy: string;
  triggeredAt: Date;
  status: "running" | "success" | "failed" | "fixing";
  duration: number;
  stages: PipelineStageData[];
}

const typeIcons = {
  web: <Laptop className="h-5 w-5" />,
  api: <Server className="h-5 w-5" />,
  service: <Server className="h-5 w-5" />,
  auth: <Monitor className="h-5 w-5" />
};

const typeColors = {
  web: "bg-secondary",
  api: "bg-error",
  service: "bg-warning",
  auth: "bg-info"
};

const statusBadges = {
  running: <Badge variant="outline" className="bg-info/10 text-info border-info/20">Running</Badge>,
  success: <Badge variant="outline" className="bg-success/10 text-success border-success/20">Success</Badge>,
  failed: <Badge variant="outline" className="bg-error/10 text-error border-error/20">Failed</Badge>,
  fixing: <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">Fixing</Badge>
};

const statusDots = {
  running: <div className="w-2 h-2 bg-info rounded-full pulse"></div>,
  success: <div className="w-2 h-2 bg-success rounded-full"></div>,
  failed: <div className="w-2 h-2 bg-error rounded-full"></div>,
  fixing: <div className="w-2 h-2 bg-warning rounded-full"></div>
};

export function PipelineItem({
  id,
  name,
  type,
  buildNumber,
  triggeredBy,
  triggeredAt,
  status,
  duration,
  stages
}: PipelineItemProps) {
  return (
    <div className="px-5 py-4 hover:bg-gray-50 transition-colors duration-150">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className={`h-8 w-8 ${typeColors[type]} rounded-md flex items-center justify-center text-white`}>
            {typeIcons[type]}
          </div>
          <div>
            <h4 className="font-medium">{name}</h4>
            <p className="text-xs text-medium">
              Last triggered {formatTimeAgo(triggeredAt)} by{" "}
              <span className="text-dark">{triggeredBy}</span>
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="text-right">
            <span className="text-xs text-medium">Build</span>
            <p className="text-sm font-medium">#{buildNumber}</p>
          </div>
          <div className="flex items-center">
            <div className="hidden sm:block">
              {statusBadges[status]}
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="ml-2 p-1 hover:bg-gray-200 rounded focus:outline-none">
                  <MoreVertical className="h-5 w-5 text-medium" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuLabel>Pipeline Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>View Details</DropdownMenuItem>
                <DropdownMenuItem>Restart Pipeline</DropdownMenuItem>
                <DropdownMenuItem>Cancel Build</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-error">Delete</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
      
      <div className="mt-4 flex flex-col sm:flex-row sm:items-center">
        <div className="flex items-center space-x-2 sm:w-1/5">
          {statusDots[status]}
          <span className="text-sm">{Math.floor(duration / 60)}:{(duration % 60).toString().padStart(2, '0')}</span>
        </div>
        <div className="mt-2 sm:mt-0 flex-1">
          <div className="flex items-center space-x-4">
            {stages.map((stage, index) => (
              <PipelineStage 
                key={`${id}-stage-${index}`} 
                name={stage.name} 
                status={stage.status} 
                isLast={index === stages.length - 1} 
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
