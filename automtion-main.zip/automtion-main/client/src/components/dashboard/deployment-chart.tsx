import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Chart } from "@/components/ui/chart";
import { cn } from "@/lib/utils";

interface DeploymentData {
  day: string;
  success: number;
  failed: number;
  warning: number;
}

export interface DeploymentChartProps {
  successRate: number;
  successRateChange: number;
  totalDeployments: number;
  totalDeploymentsChange: number;
  data: DeploymentData[];
}

export function DeploymentChart({
  successRate,
  successRateChange,
  totalDeployments,
  totalDeploymentsChange,
  data
}: DeploymentChartProps) {
  const [timeRange, setTimeRange] = useState<'daily' | 'weekly' | 'monthly'>('daily');

  return (
    <div className="bg-white rounded-lg shadow-sm">
      <div className="px-5 py-4 border-b border-gray-200 flex items-center justify-between">
        <h3 className="font-medium text-dark">Deployment Metrics</h3>
        <div className="flex space-x-2">
          <Button 
            variant="ghost" 
            size="sm"
            className={cn(
              "text-xs font-medium px-2 py-1 rounded h-auto", 
              timeRange === 'daily' ? "bg-primary/10 text-primary" : "hover:bg-gray-100"
            )}
            onClick={() => setTimeRange('daily')}
          >
            Daily
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            className={cn(
              "text-xs font-medium px-2 py-1 rounded h-auto", 
              timeRange === 'weekly' ? "bg-primary/10 text-primary" : "hover:bg-gray-100"
            )}
            onClick={() => setTimeRange('weekly')}
          >
            Weekly
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            className={cn(
              "text-xs font-medium px-2 py-1 rounded h-auto", 
              timeRange === 'monthly' ? "bg-primary/10 text-primary" : "hover:bg-gray-100"
            )}
            onClick={() => setTimeRange('monthly')}
          >
            Monthly
          </Button>
        </div>
      </div>
      <div className="px-5 py-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-sm font-medium">Success Rate</span>
            <div className="flex items-center">
              <span className="text-2xl font-semibold mr-2">{successRate}%</span>
              <span className={cn(
                "inline-flex items-center text-xs font-medium",
                successRateChange >= 0 ? "text-success" : "text-error"
              )}>
                {successRateChange >= 0 ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 10l7-7m0 0l7 7m-7-7v18" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                  </svg>
                )}
                {Math.abs(successRateChange)}%
              </span>
            </div>
          </div>
          <div>
            <span className="text-sm font-medium">Total Deployments</span>
            <div className="flex items-center">
              <span className="text-2xl font-semibold mr-2">{totalDeployments}</span>
              <span className={cn(
                "inline-flex items-center text-xs font-medium",
                totalDeploymentsChange >= 0 ? "text-success" : "text-error"
              )}>
                {totalDeploymentsChange >= 0 ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 10l7-7m0 0l7 7m-7-7v18" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                  </svg>
                )}
                {Math.abs(totalDeploymentsChange)}%
              </span>
            </div>
          </div>
        </div>
        
        <div className="h-64 w-full">
          <Chart 
            type="bar" 
            height={240}
            data={data}
            xAxisDataKey="day"
            categories={[
              { dataKey: "success", color: "hsl(var(--success))", name: "Success" },
              { dataKey: "failed", color: "hsl(var(--error))", name: "Failed" },
              { dataKey: "warning", color: "hsl(var(--warning))", name: "Warning" }
            ]}
          />
        </div>
        
        <div className="flex items-center justify-center space-x-4 text-sm">
          <div className="flex items-center">
            <span className="w-3 h-3 bg-success rounded-sm mr-2"></span>
            <span>Success</span>
          </div>
          <div className="flex items-center">
            <span className="w-3 h-3 bg-error rounded-sm mr-2"></span>
            <span>Failed</span>
          </div>
          <div className="flex items-center">
            <span className="w-3 h-3 bg-warning rounded-sm mr-2"></span>
            <span>Warning</span>
          </div>
        </div>
      </div>
    </div>
  );
}
