import { cn } from "@/lib/utils";
import { ArrowDown, ArrowUp } from "lucide-react";
import { ReactNode } from "react";

export interface MetricCardProps {
  title: string;
  value: string | number;
  subValue?: string;
  status?: "up" | "down" | "neutral";
  statusValue?: string | number;
  tag?: string;
  tagType?: "info" | "success" | "warning" | "error";
  children?: ReactNode;
}

export function MetricCard({
  title,
  value,
  subValue,
  status,
  statusValue,
  tag,
  tagType = "info",
  children
}: MetricCardProps) {
  const tagStyles = {
    info: "bg-info/10 text-info",
    success: "bg-success/10 text-success",
    warning: "bg-warning/10 text-warning",
    error: "bg-error/10 text-error"
  };

  const statusStyles = {
    up: "text-success",
    down: "text-error",
    neutral: "text-gray-500"
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-5">
      <div className="flex items-center justify-between">
        <h3 className="text-medium font-medium text-sm">{title}</h3>
        {tag && (
          <span className={cn("inline-flex items-center px-2 py-0.5 rounded text-xs font-medium", tagStyles[tagType])}>
            {tag}
          </span>
        )}
      </div>
      <div className="mt-2 flex items-end justify-between">
        <div>
          <p className="text-2xl font-semibold">{value}</p>
          {subValue && <p className="text-xs text-medium mt-1">{subValue}</p>}
        </div>
        {status && statusValue && (
          <div className={cn("inline-flex items-center px-2 py-0.5 rounded text-xs font-medium", tagStyles[status === 'up' ? 'success' : status === 'down' ? 'error' : 'info'])}>
            {status === 'up' ? <ArrowUp className="h-3 w-3 mr-1" /> : 
             status === 'down' ? <ArrowDown className="h-3 w-3 mr-1" /> : null}
            {statusValue}
          </div>
        )}
        {children && <div className="h-10 flex items-end">{children}</div>}
      </div>
    </div>
  );
}
