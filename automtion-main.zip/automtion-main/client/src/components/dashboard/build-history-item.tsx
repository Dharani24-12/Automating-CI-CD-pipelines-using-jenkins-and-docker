import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { formatTime12h } from "@/lib/utils";
import { AlertTriangle, CheckCircle2, XCircle } from "lucide-react";

export interface BuildHistoryItemProps {
  name: string;
  buildNumber: number;
  status: "completed" | "failed" | "warning";
  timestamp: Date;
  day: "Today" | "Yesterday" | string;
}

export function BuildHistoryItem({
  name,
  buildNumber,
  status,
  timestamp,
  day
}: BuildHistoryItemProps) {
  const statusIcons = {
    completed: (
      <div className="h-8 w-8 bg-success/10 text-success rounded-full flex items-center justify-center">
        <CheckCircle2 className="h-5 w-5" />
      </div>
    ),
    failed: (
      <div className="h-8 w-8 bg-error/10 text-error rounded-full flex items-center justify-center">
        <XCircle className="h-5 w-5" />
      </div>
    ),
    warning: (
      <div className="h-8 w-8 bg-warning/10 text-warning rounded-full flex items-center justify-center">
        <AlertTriangle className="h-5 w-5" />
      </div>
    )
  };

  const statusText = {
    completed: "completed",
    failed: "failed",
    warning: "warning"
  };

  return (
    <div className="py-3 flex items-center justify-between">
      <div className="flex items-center space-x-3">
        {statusIcons[status]}
        <div>
          <h4 className="font-medium">{name}</h4>
          <p className="text-xs text-medium">Build #{buildNumber} {statusText[status]}</p>
        </div>
      </div>
      <div className="text-right">
        <span className="text-xs text-medium">{day}</span>
        <p className="text-sm font-medium">{formatTime12h(timestamp)}</p>
      </div>
    </div>
  );
}
