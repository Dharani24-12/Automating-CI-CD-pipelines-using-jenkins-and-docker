import { cn } from "@/lib/utils";
import { Check, Clock, Package, Upload, X } from "lucide-react";

export type StageStatus = "success" | "failed" | "running" | "pending";

interface PipelineStageProps {
  name: string;
  status: StageStatus;
  isLast?: boolean;
}

const StageIcons = {
  build: {
    success: <Check className="h-4 w-4" />,
    failed: <X className="h-4 w-4" />,
    running: <Clock className="h-4 w-4" />,
    pending: <Check className="h-4 w-4 opacity-50" />,
  },
  test: {
    success: <Check className="h-4 w-4" />,
    failed: <X className="h-4 w-4" />,
    running: <Clock className="h-4 w-4" />,
    pending: <Check className="h-4 w-4 opacity-50" />,
  },
  package: {
    success: <Package className="h-4 w-4" />,
    failed: <X className="h-4 w-4" />,
    running: <Clock className="h-4 w-4" />,
    pending: <Package className="h-4 w-4 opacity-50" />,
  },
  deploy: {
    success: <Upload className="h-4 w-4" />,
    failed: <X className="h-4 w-4" />,
    running: <Clock className="h-4 w-4" />,
    pending: <Upload className="h-4 w-4 opacity-50" />,
  },
};

const StageColorClasses = {
  success: "bg-success",
  failed: "bg-error",
  running: "bg-info pulse",
  pending: "bg-gray-200",
};

const StageTextClasses = {
  success: "font-medium",
  failed: "font-medium",
  running: "font-medium",
  pending: "text-medium",
};

export function PipelineStage({ name, status, isLast = false }: PipelineStageProps) {
  const normalizedName = name.toLowerCase() as keyof typeof StageIcons;
  const icon = StageIcons[normalizedName]?.[status] || StageIcons.build[status];
  const colorClass = StageColorClasses[status];
  const textClass = StageTextClasses[status];

  return (
    <div className={cn("pipeline-stage flex flex-col items-center", { "after:hidden": isLast })}>
      <div className={cn("h-8 w-8 rounded-full flex items-center justify-center text-white", colorClass)}>
        {icon}
      </div>
      <span className={cn("text-xs mt-1", textClass)}>{name}</span>
    </div>
  );
}
