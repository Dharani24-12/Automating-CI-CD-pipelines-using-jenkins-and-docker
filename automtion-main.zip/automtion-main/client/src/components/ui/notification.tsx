import { AlertCircle, CheckCircle2, Info, X, XCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

export type NotificationType = "success" | "error" | "info" | "warning";

export interface NotificationProps {
  id: string;
  title: string;
  message: string;
  type: NotificationType;
  duration?: number;
  onClose?: (id: string) => void;
}

const NotificationIcons = {
  success: <CheckCircle2 className="h-5 w-5" />,
  error: <XCircle className="h-5 w-5" />,
  warning: <AlertCircle className="h-5 w-5" />,
  info: <Info className="h-5 w-5" />
};

const NotificationStyles = {
  success: "bg-success text-white",
  error: "bg-error text-white",
  warning: "bg-warning text-white",
  info: "bg-info text-white"
};

export function Notification({ 
  id, 
  title, 
  message, 
  type = "info", 
  duration = 5000, 
  onClose 
}: NotificationProps) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      // Allow animation to finish before removing
      setTimeout(() => {
        if (onClose) onClose(id);
      }, 300);
    }, duration);

    return () => {
      clearTimeout(timer);
    };
  }, [id, duration, onClose]);

  const handleClose = () => {
    setIsVisible(false);
    // Allow animation to finish before removing
    setTimeout(() => {
      if (onClose) onClose(id);
    }, 300);
  };

  return (
    <div 
      className={cn(
        "px-4 py-3 rounded-lg shadow-lg flex items-center max-w-sm", 
        NotificationStyles[type],
        isVisible ? "slide-in" : "slide-out"
      )}
    >
      <div className="flex-shrink-0 mr-3">
        {NotificationIcons[type]}
      </div>
      <div className="flex-1">
        <p className="font-medium">{title}</p>
        <p className="text-sm opacity-90">{message}</p>
      </div>
      <button className="ml-4 focus:outline-none" onClick={handleClose}>
        <X className="h-5 w-5" />
      </button>
    </div>
  );
}

export function NotificationsContainer({ 
  notifications, 
  onClose 
}: { 
  notifications: NotificationProps[],
  onClose: (id: string) => void
}) {
  return (
    <div className="fixed bottom-4 right-4 flex flex-col space-y-2 z-50">
      {notifications.map((notification) => (
        <Notification 
          key={notification.id} 
          {...notification} 
          onClose={onClose} 
        />
      ))}
    </div>
  );
}
