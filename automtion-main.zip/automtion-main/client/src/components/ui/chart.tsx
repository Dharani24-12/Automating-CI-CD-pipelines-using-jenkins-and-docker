import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

interface ChartProps {
  data: any[];
  type: 'bar' | 'line' | 'pie';
  height?: number;
  width?: number;
  dataKey?: string;
  xAxisDataKey?: string;
  categories?: Array<{
    dataKey: string;
    color: string;
    name?: string;
  }>;
}

export function Chart({
  data,
  type,
  height = 300,
  width = 500,
  dataKey = "value",
  xAxisDataKey = "name",
  categories = [{ dataKey: "value", color: "hsl(var(--chart-1))" }]
}: ChartProps) {
  if (!data || data.length === 0) {
    return (
      <div className="flex justify-center items-center" style={{ height, width }}>
        <p className="text-muted-foreground">No data available</p>
      </div>
    );
  }

  const renderChart = () => {
    switch (type) {
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={height}>
            <BarChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey={xAxisDataKey} />
              <YAxis />
              <Tooltip />
              <Legend />
              {categories.map((category, index) => (
                <Bar 
                  key={index} 
                  dataKey={category.dataKey} 
                  fill={category.color} 
                  name={category.name || category.dataKey} 
                />
              ))}
            </BarChart>
          </ResponsiveContainer>
        );
      case 'line':
        return (
          <ResponsiveContainer width="100%" height={height}>
            <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey={xAxisDataKey} />
              <YAxis />
              <Tooltip />
              <Legend />
              {categories.map((category, index) => (
                <Line 
                  key={index} 
                  type="monotone" 
                  dataKey={category.dataKey} 
                  stroke={category.color} 
                  name={category.name || category.dataKey} 
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        );
      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={height}>
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                dataKey={dataKey}
              >
                {data.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={categories[index % categories.length]?.color || `hsl(var(--chart-${(index % 5) + 1}))`} 
                  />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        );
      default:
        return null;
    }
  };

  return renderChart();
}
