import { useMemo, useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { MetricCard } from "@/components/dashboard/metric-card";
import { PipelineItem } from "@/components/dashboard/pipeline-item";
import { BuildHistoryItem } from "@/components/dashboard/build-history-item";
import { DeploymentChart } from "@/components/dashboard/deployment-chart";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useDashboardContext } from "@/context/dashboard-context";
import Sidebar from "@/components/layout/sidebar";
import { ChevronRight, Plus, RefreshCw, AlertCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function Dashboard() {
  const { 
    metrics, 
    pipelines, 
    buildHistory, 
    deploymentMetrics,
    refreshData 
  } = useDashboardContext();

  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const { data: activeData } = useQuery({
    queryKey: ['/api/pipelines/active'],
    enabled: false, // Using context state instead
  });

  const { data: historyData } = useQuery({
    queryKey: ['/api/builds/history'],
    enabled: false, // Using context state instead
  });

  const activePipelinesFiltered = useMemo(() => {
    return pipelines.filter(p => p.status === 'running' || p.status === 'fixing');
  }, [pipelines]);

  const handleRefresh = async () => {
    setIsLoading(true);
    setHasError(false);
    
    try {
      // Use the context refresh function which handles API fetching
      await refreshData();
      setIsLoading(false);
    } catch (error) {
      console.error("Failed to refresh dashboard data:", error);
      setHasError(true);
      setErrorMessage("Failed to refresh dashboard data. Please try again.");
      setIsLoading(false);
    }
  };

  // Initial data load
  useEffect(() => {
    handleRefresh();
  }, []);

  return (
    <>
      <Sidebar />
      <main className="flex-1 p-4 md:p-6 bg-gray-100">
        {/* Page Header */}
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-2xl font-semibold text-dark">Dashboard Overview</h2>
            <p className="mt-1 text-medium">Monitor your CI/CD pipelines in real-time</p>
          </div>
          <div className="mt-4 sm:mt-0 flex space-x-3">
            <Button 
              variant="outline"
              className="flex items-center bg-white" 
              onClick={handleRefresh}
              disabled={isLoading}
            >
              <RefreshCw className={`h-4 w-4 mr-1.5 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Select defaultValue="24h">
              <SelectTrigger className="border border-gray-300 rounded-md text-sm py-1.5 px-3 bg-white focus:outline-none focus:ring-2 focus:ring-primary/50 h-auto w-[150px]">
                <SelectValue placeholder="Time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">Last 24 hours</SelectItem>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="custom">Custom range</SelectItem>
              </SelectContent>
            </Select>
            <Button className="bg-primary hover:bg-primary/90 text-white py-1.5 px-4 rounded-md text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary/50 flex items-center">
              <Plus className="h-4 w-4 mr-1.5" />
              New Pipeline
            </Button>
          </div>
        </div>

        {/* Error Message */}
        {hasError && (
          <div className="mb-6 bg-error/10 border border-error/20 rounded-md p-4 flex items-center">
            <AlertCircle className="h-5 w-5 text-error mr-2" />
            <p className="text-error">{errorMessage}</p>
          </div>
        )}

        {/* Metrics cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <MetricCard
            title="Active Pipelines"
            value={metrics.activePipelines}
            subValue={`of ${metrics.totalPipelines} total`}
            tag="Live"
            tagType="info"
          >
            <div className="flex items-end space-x-1">
              <div className="w-2 h-4 bg-primary/30 rounded-t"></div>
              <div className="w-2 h-6 bg-primary/50 rounded-t"></div>
              <div className="w-2 h-8 bg-primary/70 rounded-t"></div>
              <div className="w-2 h-10 bg-primary rounded-t"></div>
              <div className="w-2 h-7 bg-primary/70 rounded-t"></div>
              <div className="w-2 h-5 bg-primary/50 rounded-t"></div>
            </div>
          </MetricCard>
          
          <MetricCard
            title="Success Rate"
            value={`${metrics.successRate}%`}
            subValue="last 24h"
            status="up"
            statusValue="6%"
          >
            <div className="w-16 h-16 rounded-full bg-success/10 flex items-center justify-center relative">
              <svg className="w-16 h-16 transform -rotate-90" viewBox="0 0 36 36">
                <circle cx="18" cy="18" r="16" fill="none" stroke="#E2E8F0" strokeWidth="3"></circle>
                <circle 
                  cx="18" 
                  cy="18" 
                  r="16" 
                  fill="none" 
                  stroke="#48BB78" 
                  strokeWidth="3" 
                  strokeDasharray={`${metrics.successRate * 100.5/100} 100.5`} 
                  strokeLinecap="round"
                ></circle>
              </svg>
              <span className="absolute text-xs font-medium text-success">{metrics.successRate}%</span>
            </div>
          </MetricCard>
          
          <MetricCard
            title="Avg Build Time"
            value={metrics.avgBuildTime}
            subValue="minutes:seconds"
            status="down"
            statusValue="12%"
          >
            <div className="h-10 flex items-end space-x-1">
              <div className="w-8 h-10 rounded-md bg-warning/20 flex items-center justify-center">
                <span className="text-xs font-medium text-warning">+0:24</span>
              </div>
            </div>
          </MetricCard>
          
          <MetricCard
            title="Failed Deployments"
            value={metrics.failedDeployments}
            subValue="total failures"
            status="down"
            statusValue="2"
          >
            <div className="flex items-center space-x-1">
              <div className="w-4 h-4 bg-error rounded flex items-center justify-center">
                <span className="text-[8px] text-white">1</span>
              </div>
              <div className="w-4 h-4 bg-error rounded flex items-center justify-center">
                <span className="text-[8px] text-white">1</span>
              </div>
              <div className="w-4 h-4 bg-error rounded flex items-center justify-center">
                <span className="text-[8px] text-white">1</span>
              </div>
            </div>
          </MetricCard>
        </div>

        {/* Active Pipelines */}
        <div className="mb-6">
          <Card>
            <CardHeader className="px-5 py-4 border-b border-gray-200 flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <CardTitle className="font-medium text-dark">Active Pipelines</CardTitle>
              <div className="mt-2 sm:mt-0 text-sm flex items-center">
                <div className="rounded-md overflow-hidden flex">
                  <Button variant="ghost" className="bg-gray-100 px-3 py-1 hover:bg-gray-200 border-r border-gray-300 h-auto rounded-none">All</Button>
                  <Button variant="ghost" className="bg-primary text-white px-3 py-1 h-auto rounded-none">Active</Button>
                  <Button variant="ghost" className="bg-gray-100 px-3 py-1 hover:bg-gray-200 border-l border-gray-300 h-auto rounded-none">Failed</Button>
                </div>
                <Button variant="ghost" size="icon" className="ml-2 p-1 hover:bg-gray-100 rounded focus:outline-none h-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-medium" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                  </svg>
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0 divide-y divide-gray-200">
              {pipelines.length > 0 ? (
                pipelines.map((pipeline) => (
                  <PipelineItem
                    key={pipeline.id}
                    id={pipeline.id}
                    name={pipeline.name}
                    type={pipeline.type}
                    buildNumber={pipeline.buildNumber}
                    triggeredBy={pipeline.triggeredBy}
                    triggeredAt={pipeline.triggeredAt}
                    status={pipeline.status}
                    duration={pipeline.duration}
                    stages={pipeline.stages}
                  />
                ))
              ) : (
                <div className="py-8 text-center text-medium">
                  <p>No active pipelines at the moment.</p>
                  <p className="text-sm mt-1">Start a new pipeline or check back later.</p>
                </div>
              )}
            </CardContent>
            <CardFooter className="px-5 py-3 bg-gray-50 text-center text-sm border-t border-gray-200">
              <a href="#" className="text-primary hover:text-primary/80 font-medium flex items-center justify-center w-full">
                View All Pipelines
                <ChevronRight className="h-4 w-4 ml-1" />
              </a>
            </CardFooter>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Build History */}
          <Card>
            <CardHeader className="px-5 py-4 border-b border-gray-200 flex items-center justify-between">
              <CardTitle className="font-medium text-dark">Recent Build History</CardTitle>
              <Button variant="ghost" size="icon" className="p-1 hover:bg-gray-100 rounded focus:outline-none h-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-medium" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                </svg>
              </Button>
            </CardHeader>
            <CardContent className="px-5 py-2 divide-y divide-gray-100">
              {buildHistory.length > 0 ? (
                buildHistory.map((build) => (
                  <BuildHistoryItem
                    key={`${build.name}-${build.buildNumber}`}
                    name={build.name}
                    buildNumber={build.buildNumber}
                    status={build.status}
                    timestamp={build.timestamp}
                    day={build.day}
                  />
                ))
              ) : (
                <div className="py-8 text-center text-medium">
                  <p>No build history available.</p>
                </div>
              )}
            </CardContent>
            <CardFooter className="px-5 py-3 bg-gray-50 text-center text-sm border-t border-gray-200">
              <a href="#" className="text-primary hover:text-primary/80 font-medium w-full">
                View Complete History
              </a>
            </CardFooter>
          </Card>

          {/* Deployment Metrics */}
          <DeploymentChart 
            successRate={deploymentMetrics.successRate}
            successRateChange={deploymentMetrics.successRateChange}
            totalDeployments={deploymentMetrics.totalDeployments}
            totalDeploymentsChange={deploymentMetrics.totalDeploymentsChange}
            data={deploymentMetrics.data}
          />
        </div>
      </main>
    </>
  );
}
