import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatTime(timeInSeconds: number): string {
  const minutes = Math.floor(timeInSeconds / 60);
  const seconds = Math.floor(timeInSeconds % 60);
  return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
}

export function formatTimeAgo(date: Date): string {
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diffInSeconds < 60) {
    return `${diffInSeconds} sec ago`;
  }
  if (diffInSeconds < 3600) {
    return `${Math.floor(diffInSeconds / 60)} min ago`;
  }
  if (diffInSeconds < 86400) {
    return `${Math.floor(diffInSeconds / 3600)} hours ago`;
  }
  if (diffInSeconds < 172800) {
    return 'Yesterday';
  }
  return date.toLocaleDateString();
}

export function formatTime12h(date: Date): string {
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric', 
    minute: '2-digit',
    hour12: true
  });
}

export function getStatusColor(status: string): string {
  switch(status.toLowerCase()) {
    case 'success':
    case 'completed':
      return 'bg-success text-white';
    case 'running':
    case 'active':
      return 'bg-info text-white';
    case 'failed':
      return 'bg-error text-white';
    case 'warning':
    case 'fixing':
      return 'bg-warning text-white';
    default:
      return 'bg-gray-200 text-gray-500';
  }
}

export function getStatusBgLight(status: string): string {
  switch(status.toLowerCase()) {
    case 'success':
    case 'completed':
      return 'bg-success/10 text-success';
    case 'running':
    case 'active':
      return 'bg-info/10 text-info';
    case 'failed':
      return 'bg-error/10 text-error';
    case 'warning':
    case 'fixing':
      return 'bg-warning/10 text-warning';
    default:
      return 'bg-gray-100 text-gray-500';
  }
}

export function generateUniqueId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
}
