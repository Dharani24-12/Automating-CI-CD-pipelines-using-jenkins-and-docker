type WebSocketHandlers = {
  onOpen?: () => void;
  onMessage?: (data: any) => void;
  onClose?: () => void;
  onError?: (error: Event) => void;
};

let socket: WebSocket | null = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;
const RECONNECT_DELAY = 2000;

export function setupWebSocket(handlers: WebSocketHandlers = {}): () => void {
  try {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    console.log(`Connecting to WebSocket at ${wsUrl}`);
    
    const connect = () => {
      try {
        socket = new WebSocket(wsUrl);

        socket.addEventListener("open", () => {
          console.log("WebSocket connection established");
          reconnectAttempts = 0;
          if (handlers.onOpen) handlers.onOpen();
        });

        socket.addEventListener("message", (event) => {
          try {
            const data = JSON.parse(event.data);
            if (handlers.onMessage) handlers.onMessage(data);
          } catch (error) {
            console.error("Failed to parse WebSocket message:", error);
          }
        });

        socket.addEventListener("close", (event) => {
          console.log("WebSocket connection closed", event);
          if (handlers.onClose) handlers.onClose();
          
          // Attempt to reconnect if it wasn't a clean close
          if (!event.wasClean && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
            console.log(`Attempting to reconnect (${reconnectAttempts + 1}/${MAX_RECONNECT_ATTEMPTS})...`);
            reconnectAttempts++;
            setTimeout(connect, RECONNECT_DELAY);
          }
        });

        socket.addEventListener("error", (event) => {
          console.error("WebSocket error:", event);
          if (handlers.onError) handlers.onError(event);
        });
      } catch (error) {
        console.error("Failed to create WebSocket:", error);
        // Still try to reconnect
        if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
          reconnectAttempts++;
          setTimeout(connect, RECONNECT_DELAY);
        }
      }
    };

    connect();

    return () => {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
    };
  } catch (error) {
    console.error("Error in setupWebSocket:", error);
    return () => {}; // Return empty cleanup function
  }
}

export function sendWebSocketMessage(message: any): boolean {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify(message));
    return true;
  }
  return false;
}

export function getWebSocketStatus(): string {
  if (!socket) return "Not Connected";
  
  switch (socket.readyState) {
    case WebSocket.CONNECTING:
      return "Connecting";
    case WebSocket.OPEN:
      return "Connected";
    case WebSocket.CLOSING:
      return "Closing";
    case WebSocket.CLOSED:
      return "Closed";
    default:
      return "Unknown";
  }
}
