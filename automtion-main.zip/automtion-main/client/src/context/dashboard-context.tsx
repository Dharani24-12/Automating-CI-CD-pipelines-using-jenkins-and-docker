import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useWebSocket } from "@/hooks/use-websocket";
import { generateUniqueId } from "@/lib/utils";

export interface Pipeline {
  id: string;
  name: string;
  type: "web" | "api" | "service" | "auth";
  buildNumber: number;
  triggeredBy: string;
  triggeredAt: Date;
  status: "running" | "success" | "failed" | "fixing";
  duration: number;
  stages: {
    name: string;
    status: "success" | "failed" | "running" | "pending";
  }[];
}

export interface BuildHistoryItem {
  name: string;
  buildNumber: number;
  status: "completed" | "failed" | "warning";
  timestamp: Date;
  day: "Today" | "Yesterday" | string;
}

export interface DashboardMetrics {
  activePipelines: number;
  totalPipelines: number;
  successRate: number;
  avgBuildTime: string;
  failedDeployments: number;
}

export interface DeploymentMetrics {
  successRate: number;
  successRateChange: number;
  totalDeployments: number;
  totalDeploymentsChange: number;
  data: {
    day: string;
    success: number;
    failed: number;
    warning: number;
  }[];
}

interface DashboardContextType {
  metrics: DashboardMetrics;
  pipelines: Pipeline[];
  buildHistory: BuildHistoryItem[];
  deploymentMetrics: DeploymentMetrics;
  refreshData: () => void;
}

const DashboardContext = createContext<DashboardContextType | undefined>(undefined);

// Initial demo data - this would normally come from the backend
const initialMetrics: DashboardMetrics = {
  activePipelines: 6,
  totalPipelines: 18,
  successRate: 93,
  avgBuildTime: "3:42",
  failedDeployments: 3
};

const initialPipelines: Pipeline[] = [
  {
    id: generateUniqueId(),
    name: "web-frontend",
    type: "web",
    buildNumber: 1293,
    triggeredBy: "John Doe",
    triggeredAt: new Date(Date.now() - 3 * 60 * 1000), // 3 mins ago
    status: "running",
    duration: 2 * 60 + 34, // 2:34
    stages: [
      { name: "Build", status: "success" },
      { name: "Test", status: "success" },
      { name: "Package", status: "running" },
      { name: "Deploy", status: "pending" }
    ]
  },
  {
    id: generateUniqueId(),
    name: "api-gateway",
    type: "api",
    buildNumber: 892,
    triggeredBy: "Sarah Jones",
    triggeredAt: new Date(Date.now() - 12 * 60 * 1000), // 12 mins ago
    status: "failed",
    duration: 2 * 60 + 45, // 2:45
    stages: [
      { name: "Build", status: "success" },
      { name: "Test", status: "failed" },
      { name: "Package", status: "pending" },
      { name: "Deploy", status: "pending" }
    ]
  },
  {
    id: generateUniqueId(),
    name: "user-service",
    type: "service",
    buildNumber: 562,
    triggeredBy: "Mike Taylor",
    triggeredAt: new Date(Date.now() - 32 * 60 * 1000), // 32 mins ago
    status: "fixing",
    duration: 5 * 60 + 12, // 5:12
    stages: [
      { name: "Build", status: "success" },
      { name: "Test", status: "success" },
      { name: "Package", status: "success" },
      { name: "Deploy", status: "failed" }
    ]
  }
];

const initialBuildHistory: BuildHistoryItem[] = [
  {
    name: "web-frontend",
    buildNumber: 1292,
    status: "completed",
    timestamp: new Date(new Date().setHours(10, 42)),
    day: "Today"
  },
  {
    name: "api-gateway",
    buildNumber: 891,
    status: "failed",
    timestamp: new Date(new Date().setHours(9, 15)),
    day: "Today"
  },
  {
    name: "auth-service",
    buildNumber: 723,
    status: "completed",
    timestamp: new Date(new Date().setHours(8, 30)),
    day: "Today"
  },
  {
    name: "user-service",
    buildNumber: 561,
    status: "completed",
    timestamp: new Date(new Date().setHours(16, 55, 0, 0) - 24 * 60 * 60 * 1000), // yesterday
    day: "Yesterday"
  },
  {
    name: "payment-service",
    buildNumber: 432,
    status: "warning",
    timestamp: new Date(new Date().setHours(14, 12, 0, 0) - 24 * 60 * 60 * 1000), // yesterday
    day: "Yesterday"
  }
];

const initialDeploymentMetrics: DeploymentMetrics = {
  successRate: 93,
  successRateChange: 6,
  totalDeployments: 42,
  totalDeploymentsChange: 12,
  data: [
    { day: "Mon", success: 8, failed: 1, warning: 0 },
    { day: "Tue", success: 12, failed: 0, warning: 0 },
    { day: "Wed", success: 10, failed: 1, warning: 0 },
    { day: "Thu", success: 6, failed: 1, warning: 0 },
    { day: "Fri", success: 11, failed: 0, warning: 1 },
    { day: "Sat", success: 9, failed: 1, warning: 0 },
    { day: "Sun", success: 14, failed: 0, warning: 0 }
  ]
};

export function DashboardProvider({ children }: { children: ReactNode }) {
  const [metrics, setMetrics] = useState<DashboardMetrics>(initialMetrics);
  const [pipelines, setPipelines] = useState<Pipeline[]>(initialPipelines);
  const [buildHistory, setBuildHistory] = useState<BuildHistoryItem[]>(initialBuildHistory);
  const [deploymentMetrics, setDeploymentMetrics] = useState<DeploymentMetrics>(initialDeploymentMetrics);

  const { isConnected } = useWebSocket({
    onMessage: (data) => {
      try {
        console.log("WebSocket message received:", data);
        if (data && data.type === 'dashboard_update') {
          // Update state based on the data received
          if (data.metrics) setMetrics(prev => ({ ...prev, ...data.metrics }));
          if (data.pipeline) {
            // Update a specific pipeline or add a new one
            setPipelines(prev => {
              const index = prev.findIndex(p => p.id === data.pipeline.id);
              if (index >= 0) {
                const updated = [...prev];
                updated[index] = { ...updated[index], ...data.pipeline };
                return updated;
              } else {
                return [...prev, data.pipeline];
              }
            });
          }
          if (data.buildHistory) {
            // Add new build history item
            setBuildHistory(prev => [data.buildHistory, ...prev].slice(0, 5));
          }
          if (data.pipelines) {
            // Replace all pipelines
            setPipelines(data.pipelines);
          }
          if (data.buildHistoryList) {
            // Replace all build history
            setBuildHistory(data.buildHistoryList);
          }
          if (data.deploymentMetrics) {
            // Update deployment metrics
            setDeploymentMetrics(prev => ({ ...prev, ...data.deploymentMetrics }));
          }
        }
      } catch (error) {
        console.error("Error processing WebSocket message:", error);
      }
    }
  });

  const refreshData = async () => {
    console.log("Refreshing dashboard data");
    try {
      // Simulate API fetch for now
      // In a real implementation, you would make an API call to get fresh data
      const apiUrl = '/api/dashboard';
      const response = await fetch(apiUrl);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch data: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Update state with fresh data
      if (data.metrics) setMetrics(data.metrics);
      if (data.pipelines) setPipelines(data.pipelines);
      if (data.buildHistory) setBuildHistory(data.buildHistory);
      if (data.deploymentMetrics) setDeploymentMetrics(data.deploymentMetrics);
      
      console.log("Dashboard data refreshed successfully");
    } catch (error) {
      console.error("Error refreshing dashboard data:", error);
      throw error; // Re-throw to let the caller handle it
    }
  };
  
  useEffect(() => {
    // Initial data load
    refreshData().catch(error => {
      console.error("Failed to load initial data:", error);
    });
    
    // Set up a timer to update running pipelines
    const timer = setInterval(() => {
      setPipelines(prev => 
        prev.map(pipeline => {
          if (pipeline.status === 'running') {
            return {
              ...pipeline,
              duration: pipeline.duration + 1
            };
          }
          return pipeline;
        })
      );
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <DashboardContext.Provider value={{
      metrics,
      pipelines,
      buildHistory,
      deploymentMetrics,
      refreshData
    }}>
      {children}
    </DashboardContext.Provider>
  );
}

export function useDashboardContext() {
  const context = useContext(DashboardContext);
  if (context === undefined) {
    throw new Error("useDashboardContext must be used within a DashboardProvider");
  }
  return context;
}
