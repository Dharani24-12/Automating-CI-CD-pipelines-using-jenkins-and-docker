import { useEffect, useRef, useState, useCallback } from 'react';

type MessageHandler = (data: any) => void;
type ConnectionStatusHandler = () => void;
type ErrorHandler = (error: Event) => void;

interface WebSocketOptions {
  url?: string;
  reconnectAttempts?: number;
  reconnectDelay?: number;
  onOpen?: ConnectionStatusHandler;
  onClose?: ConnectionStatusHandler;
  onError?: ErrorHandler;
  onMessage?: MessageHandler;
  autoConnect?: boolean;
}

export function useWebSocket({
  url,
  reconnectAttempts = 5,
  reconnectDelay = 2000,
  onOpen,
  onClose,
  onError,
  onMessage,
  autoConnect = true
}: WebSocketOptions = {}) {
  const wsUrl = url || (() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    return `${protocol}//${window.location.host}/ws`;
  })();

  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<Event | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectCountRef = useRef(0);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const connect = useCallback(() => {
    if (socketRef.current?.readyState === WebSocket.OPEN) return;
    
    try {
      const socket = new WebSocket(wsUrl);
      
      socket.onopen = () => {
        setIsConnected(true);
        setError(null);
        reconnectCountRef.current = 0;
        if (onOpen) onOpen();
      };
      
      socket.onclose = (event) => {
        setIsConnected(false);
        if (onClose) onClose();
        
        // Only attempt to reconnect if it wasn't a clean close and we haven't exceeded max attempts
        if (!event.wasClean && reconnectCountRef.current < reconnectAttempts) {
          reconnectCountRef.current += 1;
          
          if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current);
          }
          
          reconnectTimeoutRef.current = setTimeout(() => {
            connect();
          }, reconnectDelay);
        }
      };
      
      socket.onerror = (error) => {
        setError(error);
        if (onError) onError(error);
      };
      
      socket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (onMessage) onMessage(data);
        } catch (e) {
          console.error('Failed to parse WebSocket message:', e);
        }
      };
      
      socketRef.current = socket;
    } catch (error) {
      console.error('Failed to connect to WebSocket:', error);
      setError(error as Event);
    }
  }, [wsUrl, reconnectAttempts, reconnectDelay, onOpen, onClose, onError, onMessage]);

  const disconnect = useCallback(() => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.close();
    }
    
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
  }, []);

  const send = useCallback((data: any) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(typeof data === 'string' ? data : JSON.stringify(data));
      return true;
    }
    return false;
  }, []);

  // Connect when the component mounts if autoConnect is true
  useEffect(() => {
    if (autoConnect) {
      connect();
    }
    
    return () => {
      disconnect();
    };
  }, [autoConnect, connect, disconnect]);

  return {
    isConnected,
    connect,
    disconnect,
    send,
    error
  };
}
