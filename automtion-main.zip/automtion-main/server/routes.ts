import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";

// Store connected clients
const clients: Set<WebSocket> = new Set();

// Broadcast a message to all connected clients
function broadcast(data: any): void {
  const message = JSON.stringify(data);
  clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

// Send updates about pipelines periodically
async function sendPipelineUpdates(): Promise<void> {
  try {
    const pipelines = await storage.getActivePipelines();
    
    for (const pipeline of pipelines) {
      // For active pipelines, update their status
      if (pipeline.status === 'running') {
        // Update stages progress
        const updatedPipeline = await storage.updatePipelineProgress(pipeline.id);
        if (updatedPipeline) {
          // Broadcast the update
          broadcast({
            type: 'dashboard_update',
            pipeline: updatedPipeline
          });
        }
      }
    }
  } catch (error) {
    console.error("Error in sendPipelineUpdates:", error);
  }
}

// Send a notification to clients
function sendNotification(notification: { 
  id: string, 
  title: string, 
  message: string, 
  notificationType: 'success' | 'error' | 'warning' | 'info' 
}): void {
  broadcast({
    type: 'notification',
    ...notification
  });
}

// Simulate random events for demo purposes
async function simulateRandomEvents(): Promise<void> {
  try {
    const randomEvent = Math.floor(Math.random() * 100);
    
    if (randomEvent < 10) {
      // 10% chance to create a new build
      const newPipeline = await storage.startNewPipeline();
      if (newPipeline) {
        broadcast({
          type: 'dashboard_update',
          pipeline: newPipeline
        });
        
        sendNotification({
          id: `new-build-${Date.now()}`,
          title: 'Build Started',
          message: `${newPipeline.name} #${newPipeline.buildNumber} has started`,
          notificationType: 'info'
        });
      }
    } else if (randomEvent < 20) {
      // 10% chance to complete a build
      const completedPipeline = await storage.completePipeline();
      if (completedPipeline) {
        broadcast({
          type: 'dashboard_update',
          pipeline: completedPipeline
        });
        
        // Add to build history
        const historyItem = await storage.addToBuildHistory(completedPipeline);
        broadcast({
          type: 'dashboard_update',
          buildHistory: historyItem
        });
        
        // Update metrics
        const updatedMetrics = await storage.getMetrics();
        broadcast({
          type: 'dashboard_update',
          metrics: updatedMetrics
        });
        
        sendNotification({
          id: `build-complete-${Date.now()}`,
          title: completedPipeline.status === 'success' ? 'Build Succeeded' : 'Build Failed',
          message: `${completedPipeline.name} #${completedPipeline.buildNumber} ${completedPipeline.status === 'success' ? 'completed successfully' : 'failed'}`,
          notificationType: completedPipeline.status === 'success' ? 'success' : 'error'
        });
      }
    }
  } catch (error) {
    console.error("Error in simulateRandomEvents:", error);
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', async (ws) => {
    try {
      // Add client to set
      clients.add(ws);
      console.log('WebSocket client connected');

      // Get initial data
      const [metrics, pipelines, buildHistory, deploymentMetrics] = await Promise.all([
        storage.getMetrics(),
        storage.getActivePipelines(),
        storage.getBuildHistory(),
        storage.getDeploymentMetrics()
      ]);

      // Send initial data
      ws.send(JSON.stringify({
        type: 'dashboard_update',
        metrics,
        pipelines,
        buildHistory,
        deploymentMetrics
      }));

      ws.on('message', async (message) => {
        try {
          const data = JSON.parse(message.toString());
          console.log('Received message:', data);
          
          // Handle client messages if needed
          if (data.type === 'refresh') {
            // Get fresh data
            const [metrics, pipelines, buildHistory, deploymentMetrics] = await Promise.all([
              storage.getMetrics(),
              storage.getActivePipelines(),
              storage.getBuildHistory(),
              storage.getDeploymentMetrics()
            ]);

            // Send refreshed data
            ws.send(JSON.stringify({
              type: 'dashboard_update',
              metrics,
              pipelines,
              buildHistory,
              deploymentMetrics
            }));
          }
        } catch (error) {
          console.error('Error parsing message:', error);
        }
      });

      ws.on('close', () => {
        clients.delete(ws);
        console.log('WebSocket client disconnected');
      });

      ws.on('error', (error) => {
        console.error('WebSocket error:', error);
        clients.delete(ws);
      });
    } catch (error) {
      console.error('Error handling WebSocket connection:', error);
      ws.close();
    }
  });

  // Set up API routes
  app.get('/api/dashboard', async (req, res) => {
    try {
      const [metrics, pipelines, buildHistory, deploymentMetrics] = await Promise.all([
        storage.getMetrics(),
        storage.getActivePipelines(),
        storage.getBuildHistory(),
        storage.getDeploymentMetrics()
      ]);

      res.json({
        metrics,
        pipelines,
        buildHistory,
        deploymentMetrics
      });
    } catch (error) {
      console.error('Error getting dashboard data:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get('/api/pipelines/active', async (req, res) => {
    try {
      res.json(await storage.getActivePipelines());
    } catch (error) {
      console.error('Error getting active pipelines:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get('/api/pipelines/:id', async (req, res) => {
    try {
      const pipeline = await storage.getPipeline(req.params.id);
      if (pipeline) {
        res.json(pipeline);
      } else {
        res.status(404).json({ message: 'Pipeline not found' });
      }
    } catch (error) {
      console.error('Error getting pipeline:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get('/api/builds/history', async (req, res) => {
    try {
      res.json(await storage.getBuildHistory());
    } catch (error) {
      console.error('Error getting build history:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get('/api/metrics', async (req, res) => {
    try {
      res.json(await storage.getMetrics());
    } catch (error) {
      console.error('Error getting metrics:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get('/api/deployment-metrics', async (req, res) => {
    try {
      res.json(await storage.getDeploymentMetrics());
    } catch (error) {
      console.error('Error getting deployment metrics:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Setup update intervals for real-time data
  setInterval(() => {
    sendPipelineUpdates().catch(error => {
      console.error("Error in pipeline updates interval:", error);
    });
  }, 5000); // Update pipelines every 5 seconds
  
  setInterval(() => {
    simulateRandomEvents().catch(error => {
      console.error("Error in random events interval:", error);
    });
  }, 15000); // Random events every 15 seconds

  return httpServer;
}
