import { 
  Pipeline, 
  BuildHistoryItem, 
  DashboardMetrics, 
  DeploymentMetrics 
} from "@shared/schema";
import { DatabaseStorage } from "./database-storage";

export interface IStorage {
  getMetrics(): Promise<DashboardMetrics>;
  getActivePipelines(): Promise<Pipeline[]>;
  getPipeline(id: string): Promise<Pipeline | undefined>;
  getBuildHistory(): Promise<BuildHistoryItem[]>;
  getDeploymentMetrics(): Promise<DeploymentMetrics>;
  updatePipelineProgress(id: string): Promise<Pipeline | undefined>;
  startNewPipeline(): Promise<Pipeline | undefined>;
  completePipeline(): Promise<Pipeline | undefined>;
  addToBuildHistory(pipeline: Pipeline): Promise<BuildHistoryItem>;
}

// Create an instance of the database storage
export const storage = new DatabaseStorage();
