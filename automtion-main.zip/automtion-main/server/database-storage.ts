import { db } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";
import {
  Pipeline,
  BuildHistoryItem,
  DashboardMetrics,
  DeploymentMetrics,
  pipelines,
  buildHistory,
  pipelineStages,
  metrics,
  deploymentMetrics,
  InsertPipeline,
  InsertBuildHistory,
  InsertPipelineStage
} from "@shared/schema";
import { IStorage } from "./storage";

// Generate a unique ID
function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
}

// Format time in MM:SS format
function formatTime(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
}

// Random person names for demo
const people = [
  "John Doe",
  "Sarah Jones",
  "Mike Taylor",
  "Emma Wilson",
  "James Smith",
  "Lisa Johnson",
  "Alex Brown",
  "Olivia Davis"
];

// Pipeline demos
const pipelineTemplates = [
  { name: "web-frontend", type: "web" },
  { name: "api-gateway", type: "api" },
  { name: "user-service", type: "service" },
  { name: "auth-service", type: "auth" },
  { name: "payment-service", type: "service" },
  { name: "notification-service", type: "service" },
  { name: "analytics-service", type: "api" },
  { name: "mobile-client", type: "web" }
];

export class DatabaseStorage implements IStorage {
  private buildNumbers: Map<string, number>;

  constructor() {
    this.buildNumbers = new Map();
    
    // Initialize buildNumbers from database
    this.initializeBuildNumbers();
  }

  private async initializeBuildNumbers(): Promise<void> {
    try {
      // Get the max build number for each pipeline name
      const results = await db.execute(sql`
        SELECT name, MAX(build_number) as max_build
        FROM ${pipelines}
        GROUP BY name
      `);

      for (const row of results.rows) {
        if (row.name && row.max_build) {
          this.buildNumbers.set(
            String(row.name), 
            parseInt(String(row.max_build))
          );
        }
      }

      // Initialize default build numbers for templates not in database
      pipelineTemplates.forEach(template => {
        if (!this.buildNumbers.has(template.name)) {
          this.buildNumbers.set(template.name, 1000);
        }
      });

      console.log("Build numbers initialized:", Object.fromEntries(this.buildNumbers));
    } catch (error) {
      console.error("Error initializing build numbers:", error);
      
      // Set default build numbers if database query fails
      pipelineTemplates.forEach(template => {
        this.buildNumbers.set(template.name, 1000);
      });
    }
  }

  async getMetrics(): Promise<DashboardMetrics> {
    try {
      // Try to get the latest metrics
      const latestMetrics = await db.query.metrics.findFirst({
        orderBy: [desc(metrics.updatedAt)]
      });

      if (latestMetrics) {
        return {
          activePipelines: latestMetrics.activePipelines,
          totalPipelines: latestMetrics.totalPipelines,
          successRate: latestMetrics.successRate,
          avgBuildTime: latestMetrics.avgBuildTime,
          failedDeployments: latestMetrics.failedDeployments
        };
      }

      // If no metrics exist, create default metrics
      const defaultMetrics = {
        activePipelines: 0,
        totalPipelines: 0,
        successRate: 0,
        avgBuildTime: "0:00",
        failedDeployments: 0
      };

      // Save default metrics to database
      await db.insert(metrics).values({
        ...defaultMetrics,
        updatedAt: new Date()
      });

      return defaultMetrics;
    } catch (error) {
      console.error("Error getting metrics:", error);
      // Return default metrics if database query fails
      return {
        activePipelines: 0,
        totalPipelines: 0,
        successRate: 0,
        avgBuildTime: "0:00",
        failedDeployments: 0
      };
    }
  }

  async getActivePipelines(): Promise<Pipeline[]> {
    try {
      // Get all pipelines
      const pipelineResults = await db.query.pipelines.findMany({
        orderBy: [desc(pipelines.updatedAt)]
      });

      // For each pipeline, get its stages
      const result: Pipeline[] = [];
      
      for (const pipeline of pipelineResults) {
        const stageResults = await db.query.pipelineStages.findMany({
          where: eq(pipelineStages.pipelineId, pipeline.id),
          orderBy: [pipelineStages.order]
        });

        // Map stages to the expected format
        const mappedStages = stageResults.map(stage => ({
          name: stage.name,
          status: stage.status as "success" | "failed" | "running" | "pending"
        }));

        // Add the pipeline with its stages to the result
        result.push({
          id: pipeline.id,
          name: pipeline.name,
          type: pipeline.type as "web" | "api" | "service" | "auth",
          buildNumber: pipeline.buildNumber,
          triggeredBy: pipeline.triggeredBy,
          triggeredAt: pipeline.triggeredAt,
          status: pipeline.status as "running" | "success" | "failed" | "fixing",
          duration: pipeline.duration,
          stages: mappedStages
        });
      }

      return result;
    } catch (error) {
      console.error("Error getting active pipelines:", error);
      return [];
    }
  }

  async getPipeline(id: string): Promise<Pipeline | undefined> {
    try {
      // Get the pipeline
      const pipeline = await db.query.pipelines.findFirst({
        where: eq(pipelines.id, id)
      });

      if (!pipeline) {
        return undefined;
      }

      // Get the pipeline stages
      const stageResults = await db.query.pipelineStages.findMany({
        where: eq(pipelineStages.pipelineId, id),
        orderBy: [pipelineStages.order]
      });

      // Map stages to the expected format
      const mappedStages = stageResults.map(stage => ({
        name: stage.name,
        status: stage.status as "success" | "failed" | "running" | "pending"
      }));

      // Return the pipeline with its stages
      return {
        id: pipeline.id,
        name: pipeline.name,
        type: pipeline.type as "web" | "api" | "service" | "auth",
        buildNumber: pipeline.buildNumber,
        triggeredBy: pipeline.triggeredBy,
        triggeredAt: pipeline.triggeredAt,
        status: pipeline.status as "running" | "success" | "failed" | "fixing",
        duration: pipeline.duration,
        stages: mappedStages
      };
    } catch (error) {
      console.error("Error getting pipeline:", error);
      return undefined;
    }
  }

  async getBuildHistory(): Promise<BuildHistoryItem[]> {
    try {
      // Get build history ordered by timestamp (newest first)
      const historyItems = await db.query.buildHistory.findMany({
        orderBy: [desc(buildHistory.timestamp)],
        limit: 10
      });

      return historyItems.map(item => ({
        id: item.id,
        name: item.name,
        buildNumber: item.buildNumber,
        status: item.status as "completed" | "failed" | "warning",
        timestamp: item.timestamp,
        day: item.day
      }));
    } catch (error) {
      console.error("Error getting build history:", error);
      return [];
    }
  }

  async getDeploymentMetrics(): Promise<DeploymentMetrics> {
    try {
      // Try to get the latest deployment metrics
      const latestMetrics = await db.query.deploymentMetrics.findFirst({
        orderBy: [desc(deploymentMetrics.updatedAt)]
      });

      if (latestMetrics) {
        return {
          successRate: latestMetrics.successRate,
          successRateChange: latestMetrics.successRateChange,
          totalDeployments: latestMetrics.totalDeployments,
          totalDeploymentsChange: latestMetrics.totalDeploymentsChange,
          data: latestMetrics.data
        };
      }

      // If no metrics exist, create default metrics with mock data
      const defaultData = [
        { day: "Mon", success: 0, failed: 0, warning: 0 },
        { day: "Tue", success: 0, failed: 0, warning: 0 },
        { day: "Wed", success: 0, failed: 0, warning: 0 },
        { day: "Thu", success: 0, failed: 0, warning: 0 },
        { day: "Fri", success: 0, failed: 0, warning: 0 },
        { day: "Sat", success: 0, failed: 0, warning: 0 },
        { day: "Sun", success: 0, failed: 0, warning: 0 }
      ];

      const defaultMetrics = {
        successRate: 0,
        successRateChange: 0,
        totalDeployments: 0,
        totalDeploymentsChange: 0,
        data: defaultData
      };

      // Save default metrics to database
      await db.insert(deploymentMetrics).values({
        ...defaultMetrics,
        data: defaultData,
        updatedAt: new Date()
      });

      return defaultMetrics;
    } catch (error) {
      console.error("Error getting deployment metrics:", error);
      
      // Return default metrics if database query fails
      const defaultData = [
        { day: "Mon", success: 0, failed: 0, warning: 0 },
        { day: "Tue", success: 0, failed: 0, warning: 0 },
        { day: "Wed", success: 0, failed: 0, warning: 0 },
        { day: "Thu", success: 0, failed: 0, warning: 0 },
        { day: "Fri", success: 0, failed: 0, warning: 0 },
        { day: "Sat", success: 0, failed: 0, warning: 0 },
        { day: "Sun", success: 0, failed: 0, warning: 0 }
      ];

      return {
        successRate: 0,
        successRateChange: 0,
        totalDeployments: 0,
        totalDeploymentsChange: 0,
        data: defaultData
      };
    }
  }

  async updatePipelineProgress(id: string): Promise<Pipeline | undefined> {
    try {
      // Get the pipeline
      const pipeline = await this.getPipeline(id);
      if (!pipeline || pipeline.status !== 'running') {
        return undefined;
      }

      // Increment duration
      const updatedDuration = pipeline.duration + 1;

      // Find the current running stage
      const runningStageIndex = pipeline.stages.findIndex(s => s.status === 'running');
      if (runningStageIndex !== -1) {
        // Randomly advance to next stage (around 20% chance each update)
        if (Math.random() < 0.2) {
          // Update the stage status to success
          await db.update(pipelineStages)
            .set({ status: 'success' })
            .where(
              and(
                eq(pipelineStages.pipelineId, id),
                eq(pipelineStages.order, runningStageIndex)
              )
            );

          // If there's a next stage, set it to running
          if (runningStageIndex < pipeline.stages.length - 1) {
            await db.update(pipelineStages)
              .set({ status: 'running' })
              .where(
                and(
                  eq(pipelineStages.pipelineId, id),
                  eq(pipelineStages.order, runningStageIndex + 1)
                )
              );
          } else {
            // If this was the last stage, complete the pipeline
            await db.update(pipelines)
              .set({ 
                status: 'success',
                updatedAt: new Date()
              })
              .where(eq(pipelines.id, id));

            // Add to build history
            await this.addToBuildHistory(pipeline);

            // Update metrics
            await this.updateMetricsOnCompletion(pipeline);
          }
        }
      }

      // Update pipeline duration
      await db.update(pipelines)
        .set({ 
          duration: updatedDuration,
          updatedAt: new Date()
        })
        .where(eq(pipelines.id, id));

      // Get the updated pipeline
      return await this.getPipeline(id);
    } catch (error) {
      console.error("Error updating pipeline progress:", error);
      return undefined;
    }
  }

  async startNewPipeline(): Promise<Pipeline | undefined> {
    try {
      // Randomly select a pipeline template
      const template = pipelineTemplates[Math.floor(Math.random() * pipelineTemplates.length)];
      
      // Get or initialize a new build number
      const buildNumber = (this.buildNumbers.get(template.name) || 1000) + 1;
      this.buildNumbers.set(template.name, buildNumber);
      
      // Generate a unique ID
      const id = generateId();

      // Create a new pipeline
      const newPipeline: InsertPipeline = {
        id,
        name: template.name,
        type: template.type,
        buildNumber,
        triggeredBy: people[Math.floor(Math.random() * people.length)],
        triggeredAt: new Date(),
        status: "running",
        duration: 0,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      // Insert the pipeline
      await db.insert(pipelines).values(newPipeline);
      
      // Create stages for the pipeline
      const stages: InsertPipelineStage[] = [
        { pipelineId: id, name: "Build", status: "running", order: 0 },
        { pipelineId: id, name: "Test", status: "pending", order: 1 },
        { pipelineId: id, name: "Package", status: "pending", order: 2 },
        { pipelineId: id, name: "Deploy", status: "pending", order: 3 }
      ];
      
      // Insert the stages
      await db.insert(pipelineStages).values(stages);
      
      // Update metrics
      const currentMetrics = await this.getMetrics();
      await db.insert(metrics).values({
        activePipelines: currentMetrics.activePipelines + 1,
        totalPipelines: currentMetrics.totalPipelines,
        successRate: currentMetrics.successRate,
        avgBuildTime: currentMetrics.avgBuildTime,
        failedDeployments: currentMetrics.failedDeployments,
        updatedAt: new Date()
      });
      
      // Return the new pipeline with its stages
      return {
        id,
        name: template.name,
        type: template.type as "web" | "api" | "service" | "auth",
        buildNumber,
        triggeredBy: newPipeline.triggeredBy,
        triggeredAt: newPipeline.triggeredAt,
        status: "running",
        duration: 0,
        stages: [
          { name: "Build", status: "running" },
          { name: "Test", status: "pending" },
          { name: "Package", status: "pending" },
          { name: "Deploy", status: "pending" }
        ]
      };
    } catch (error) {
      console.error("Error starting new pipeline:", error);
      return undefined;
    }
  }

  async completePipeline(): Promise<Pipeline | undefined> {
    try {
      // Find a running pipeline to complete
      const runningPipelines = await db.query.pipelines.findMany({
        where: eq(pipelines.status, 'running')
      });
      
      if (runningPipelines.length === 0) {
        return undefined;
      }
      
      // Randomly select one
      const pipeline = runningPipelines[Math.floor(Math.random() * runningPipelines.length)];
      
      // 80% chance of success, 20% chance of failure
      const success = Math.random() < 0.8;
      
      // Get the stages
      const stages = await db.query.pipelineStages.findMany({
        where: eq(pipelineStages.pipelineId, pipeline.id),
        orderBy: [pipelineStages.order]
      });
      
      if (success) {
        // Complete all stages successfully
        for (const stage of stages) {
          await db.update(pipelineStages)
            .set({ status: 'success' })
            .where(eq(pipelineStages.id, stage.id));
        }
        
        // Update pipeline status
        await db.update(pipelines)
          .set({ 
            status: 'success',
            updatedAt: new Date()
          })
          .where(eq(pipelines.id, pipeline.id));
      } else {
        // Fail at a random stage
        const failStageIndex = Math.floor(Math.random() * stages.length);
        
        for (let i = 0; i < stages.length; i++) {
          if (i < failStageIndex) {
            await db.update(pipelineStages)
              .set({ status: 'success' })
              .where(eq(pipelineStages.id, stages[i].id));
          } else if (i === failStageIndex) {
            await db.update(pipelineStages)
              .set({ status: 'failed' })
              .where(eq(pipelineStages.id, stages[i].id));
          } else {
            await db.update(pipelineStages)
              .set({ status: 'pending' })
              .where(eq(pipelineStages.id, stages[i].id));
          }
        }
        
        // Update pipeline status
        await db.update(pipelines)
          .set({ 
            status: 'failed',
            updatedAt: new Date()
          })
          .where(eq(pipelines.id, pipeline.id));
      }
      
      // Get the updated pipeline
      const updatedPipeline = await this.getPipeline(pipeline.id);
      
      if (updatedPipeline) {
        // Update metrics
        await this.updateMetricsOnCompletion(updatedPipeline);
        
        // Add to build history
        await this.addToBuildHistory(updatedPipeline);
      }
      
      return updatedPipeline;
    } catch (error) {
      console.error("Error completing pipeline:", error);
      return undefined;
    }
  }

  async addToBuildHistory(pipeline: Pipeline): Promise<BuildHistoryItem> {
    try {
      const today = new Date();
      const isToday = pipeline.triggeredAt.getDate() === today.getDate() &&
                     pipeline.triggeredAt.getMonth() === today.getMonth() &&
                     pipeline.triggeredAt.getFullYear() === today.getFullYear();
      
      const isYesterday = pipeline.triggeredAt.getDate() === today.getDate() - 1 &&
                          pipeline.triggeredAt.getMonth() === today.getMonth() &&
                          pipeline.triggeredAt.getFullYear() === today.getFullYear();
      
      const day = isToday ? 'Today' : isYesterday ? 'Yesterday' : pipeline.triggeredAt.toLocaleDateString();
      
      const historyItem: InsertBuildHistory = {
        name: pipeline.name,
        buildNumber: pipeline.buildNumber,
        status: pipeline.status === 'success' ? 'completed' : pipeline.status === 'failed' ? 'failed' : 'warning',
        timestamp: new Date(),
        day,
        createdAt: new Date()
      };
      
      // Insert the history item
      const [insertedItem] = await db.insert(buildHistory).values(historyItem).returning();
      
      return {
        id: insertedItem.id,
        name: insertedItem.name,
        buildNumber: insertedItem.buildNumber,
        status: insertedItem.status as "completed" | "failed" | "warning",
        timestamp: insertedItem.timestamp,
        day: insertedItem.day
      };
    } catch (error) {
      console.error("Error adding to build history:", error);
      
      // Return a backup item in case of error
      return {
        name: pipeline.name,
        buildNumber: pipeline.buildNumber,
        status: pipeline.status === 'success' ? 'completed' : 'failed',
        timestamp: new Date(),
        day: 'Today'
      };
    }
  }

  private async updateMetricsOnCompletion(pipeline: Pipeline): Promise<void> {
    try {
      // Get current metrics
      const currentMetrics = await this.getMetrics();
      
      // Get build history to calculate success rate
      const buildHistoryItems = await this.getBuildHistory();
      const totalBuilds = buildHistoryItems.length + 1; // +1 for the current pipeline
      const successfulBuilds = buildHistoryItems.filter(b => b.status === 'completed').length + (pipeline.status === 'success' ? 1 : 0);
      
      // Calculate new success rate
      const newSuccessRate = totalBuilds > 0 ? Math.round((successfulBuilds / totalBuilds) * 100) : 0;
      
      // Get active pipelines count
      const activePipelines = (await db.query.pipelines.findMany({
        where: eq(pipelines.status, 'running')
      })).length;
      
      // Update metrics
      await db.insert(metrics).values({
        activePipelines,
        totalPipelines: currentMetrics.totalPipelines,
        successRate: newSuccessRate,
        avgBuildTime: currentMetrics.avgBuildTime,
        failedDeployments: pipeline.status === 'failed' ? currentMetrics.failedDeployments + 1 : currentMetrics.failedDeployments,
        updatedAt: new Date()
      });
      
      // Update deployment metrics
      const currentDeploymentMetrics = await this.getDeploymentMetrics();
      const dayIndex = new Date().getDay(); // 0 = Sunday, 1 = Monday, ...
      const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      const day = dayNames[dayIndex];
      
      const newData = [...currentDeploymentMetrics.data];
      const dayData = newData.find(d => d.day === day);
      
      if (dayData) {
        if (pipeline.status === 'success') {
          dayData.success += 1;
        } else if (pipeline.status === 'failed') {
          dayData.failed += 1;
        }
      }
      
      // Update the deployment metrics in the database
      await db.insert(deploymentMetrics).values({
        successRate: newSuccessRate,
        successRateChange: newSuccessRate - currentDeploymentMetrics.successRate,
        totalDeployments: currentDeploymentMetrics.totalDeployments + 1,
        totalDeploymentsChange: 1,
        data: newData,
        updatedAt: new Date()
      });
    } catch (error) {
      console.error("Error updating metrics on completion:", error);
    }
  }
}